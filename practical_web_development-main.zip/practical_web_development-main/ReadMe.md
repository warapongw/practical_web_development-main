## Practical Web Development with: Docker, Django, Nginx, Redis and Gunicorn

[Go to Transylvanian Academy Web Site](https://transylvanianacademy.pythonanywhere.com/courses/1/)
