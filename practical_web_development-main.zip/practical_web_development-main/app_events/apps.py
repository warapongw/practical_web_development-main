from django.apps import AppConfig


class EventsConfig(AppConfig):
    name = 'app_events'
    verbose_name = 'events'
